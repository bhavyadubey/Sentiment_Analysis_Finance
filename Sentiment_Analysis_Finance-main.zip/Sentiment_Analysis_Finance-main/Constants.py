hash_tag_list = {

    'Nifty': [
        'INDMarketsLIVE', # Nifty 50
        'Nifty50trade',
        'forum_stock',
        'Nifty50Striker',
        'livemint',
        'moneycontrolcom',
        'MSChawla555'
    ],
    'Mahindra & Mahindra Limited': [
        'anandmahindra' # Mahindra&Mahindra
    ],
    'Bajaj Finserv Limited': [
        'Bajaj_Finserv', # Bajaj_Finserv:
        'Bajaj_Finance',
        'sanjivrbajaj'
    ],
    'Bajaj Auto Limited': [
        'BajajAutoFin'
    ],
    'Tata Motors Limited': [
        'TataMotors_Cars', # TATA Motors
        'TataMotors',
        'TataCompanies',
        'RNTata2000'
    ],
    'Maruti Suzuki India Limited': [
        'Maruti_Corp', # Maruti Suzuki India Ltd
        'NexaExperience',
        'MSArenaOfficial'
    ],
    'Reliance Industries Limited': [
        'reliancegroup', # Reliance
        'reliancejio',
        'RelianceCapital',
        'RelianceIndustries'
    ]
}