# Sentiment_Analysis_Finance
In this project we are going to predict the stock price of different companies based on the sentiments of the news and tweets related to particular company.


# Link for IR assignments

1. https://colab.research.google.com/drive/17q2R5VBPfFOrc5qDD_ORNmMfKZXg0TMz?usp=sharing
2. https://colab.research.google.com/drive/1PtVfrf-wnOt4Neka0AhbKwsNEKVp-LFV?usp=sharing
